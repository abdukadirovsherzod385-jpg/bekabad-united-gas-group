import SwiftUI

@main
struct BekabadGasApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
