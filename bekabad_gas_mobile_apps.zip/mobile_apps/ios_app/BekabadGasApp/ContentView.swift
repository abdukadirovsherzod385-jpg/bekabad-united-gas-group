import SwiftUI

struct ContentView: View {
    @State private var fullName = ""
    @State private var phone = ""
    @State private var service = "1. Газ жиҳозлари носозлиги"
    @State private var address = ""
    @State private var comment = ""
    @State private var showingAlert = false
    @State private var alertMessage = ""
    @State private var isSubmitting = false

    let services = [
        "1. Газ жиҳозлари носозлиги бўйича",
        "2. Газ сизиб чиқиши (Шошилинч)",
        "3. Дудбуронларни тозалаш бўйича",
        "4. Газ лойиҳа ва смета ҳужжатлари"
    ]

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 20) {
                    // Header Logo & Branding
                    VStack(spacing: 6) {
                        Image(systemName: "flame.fill")
                            .font(.system(size: 46))
                            .foregroundStyle(LinearGradient(colors: [.orange, .red], startPoint: .top, endPoint: .bottom))
                        
                        Text("«BEKABAD UNITED GAS GROUP»")
                            .font(.headline)
                            .fontWeight(.black)
                            .foregroundColor(.primary)
                        
                        Text("Аҳоли газ жиҳозларига хизмат кўрсатиш")
                            .font(.caption)
                            .foregroundColor(.secondary)
                    }
                    .padding(.top, 10)

                    // 🚨 FAVQULODDA CHAQIRUV BO'LIMI (EMERGENCY SPEED DIAL)
                    VStack(alignment: .leading, spacing: 12) {
                        HStack {
                            Image(systemName: "exclamationmark.triangle.fill")
                                .foregroundColor(.yellow)
                            Text("ФАВҚУЛОДДА ТЕЗКОР ЧАҚИРУВ")
                                .font(.subheadline)
                                .fontWeight(.bold)
                                .foregroundColor(.white)
                        }
                        
                        // 104 Gaz Avariya
                        Button(action: {
                            triggerHaptic()
                            callPhone("104")
                        }) {
                            HStack {
                                VStack(alignment: .leading, spacing: 2) {
                                    Text("Газ авария хизмати")
                                        .font(.caption2)
                                        .foregroundColor(.white.opacity(0.85))
                                    Text("🔥 104 АВАРИЯ")
                                        .font(.title2)
                                        .fontWeight(.black)
                                        .foregroundColor(.white)
                                }
                                Spacer()
                                Image(systemName: "phone.fill")
                                    .font(.title3)
                                    .foregroundColor(.white)
                            }
                            .padding()
                            .background(Color.red)
                            .cornerRadius(14)
                            .shadow(color: .red.opacity(0.5), radius: 6, x: 0, y: 3)
                        }

                        // Dispetcher: +998 99 823 01 88
                        Button(action: {
                            triggerHaptic()
                            callPhone("+998998230188")
                        }) {
                            HStack {
                                VStack(alignment: .leading, spacing: 2) {
                                    Text("Корхона бош диспетчери")
                                        .font(.caption2)
                                        .foregroundColor(.secondary)
                                    Text("📞 +998 99 823 01 88")
                                        .font(.headline)
                                        .fontWeight(.bold)
                                        .foregroundColor(.blue)
                                }
                                Spacer()
                                Image(systemName: "phone.circle.fill")
                                    .font(.title2)
                                    .foregroundColor(.blue)
                            }
                            .padding()
                            .background(Color(UIColor.secondarySystemBackground))
                            .cornerRadius(14)
                        }

                        // Bekobod GTB ADX: +998 55 903 22 14
                        Button(action: {
                            triggerHaptic()
                            callPhone("+998559032214")
                        }) {
                            HStack {
                                VStack(alignment: .leading, spacing: 2) {
                                    Text("Бекобод шаҳар газ ГТБ АДХ")
                                        .font(.caption2)
                                        .foregroundColor(.secondary)
                                    Text("☎️ +998 55 903 22 14")
                                        .font(.headline)
                                        .fontWeight(.bold)
                                        .foregroundColor(.primary)
                                }
                                Spacer()
                                Image(systemName: "phone.circle.fill")
                                    .font(.title2)
                                    .foregroundColor(.red)
                            }
                            .padding()
                            .background(Color(UIColor.secondarySystemBackground))
                            .cornerRadius(14)
                        }

                        // Qisqa favqulodda raqamlar paneli
                        HStack(spacing: 8) {
                            EmergencyMiniButton(title: "101 Ёнғин", num: "101", color: .orange)
                            EmergencyMiniButton(title: "103 Тез ёрдам", num: "103", color: .green)
                            EmergencyMiniButton(title: "112 ФВВ", num: "112", color: .indigo)
                        }
                    }
                    .padding()
                    .background(
                        LinearGradient(colors: [Color(red: 0.5, green: 0.1, blue: 0.1), Color(red: 0.7, green: 0.1, blue: 0.1)], startPoint: .topLeading, endPoint: .bottomTrailing)
                    )
                    .cornerRadius(20)
                    .padding(.horizontal)

                    // 💬 TELEGRAM BOT & WEB INTEGRATSIYASI
                    HStack(spacing: 12) {
                        Button(action: {
                            triggerHaptic()
                            if let url = URL(string: "tg://resolve?domain=bekabad_united_gas_group_bot") {
                                if UIApplication.shared.canOpenURL(url) {
                                    UIApplication.shared.open(url)
                                } else if let webTg = URL(string: "https://t.me/bekabad_united_gas_group_bot") {
                                    UIApplication.shared.open(webTg)
                                }
                            }
                        }) {
                            HStack {
                                Image(systemName: "paperplane.fill")
                                Text("Telegram Бот")
                            }
                            .font(.subheadline)
                            .fontWeight(.bold)
                            .foregroundColor(.white)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 14)
                            .background(Color(red: 0.0, green: 0.53, blue: 0.8))
                            .cornerRadius(14)
                        }

                        Button(action: {
                            triggerHaptic()
                            if let url = URL(string: "https://bekabadgas.surge.sh") {
                                UIApplication.shared.open(url)
                            }
                        }) {
                            HStack {
                                Image(systemName: "safari.fill")
                                Text("Расмий сайт")
                            }
                            .font(.subheadline)
                            .fontWeight(.bold)
                            .foregroundColor(.white)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 14)
                            .background(Color(red: 0.05, green: 0.28, blue: 0.63))
                            .cornerRadius(14)
                        }
                    }
                    .padding(.horizontal)

                    // 📝 ARIZA QOLDIRISH FORMASI
                    VStack(alignment: .leading, spacing: 14) {
                        Text("Онлайн ариза қолдириш")
                            .font(.title3)
                            .fontWeight(.bold)

                        VStack(spacing: 12) {
                            TextField("Исм-фамилиянгиз", text: $fullName)
                                .textFieldStyle(.roundedBorder)

                            TextField("Телефон рақамингиз (+998 ...)", text: $phone)
                                .keyboardType(.phonePad)
                                .textFieldStyle(.roundedBorder)

                            Picker("Хизмат тури", selection: $service) {
                                ForEach(services, id: \.self) {
                                    Text($0)
                                }
                            }
                            .pickerStyle(.menu)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding(8)
                            .background(Color(UIColor.secondarySystemBackground))
                            .cornerRadius(8)

                            TextField("Яшаш манзилингиз (Маҳалла, кўча, уй)", text: $address)
                                .textFieldStyle(.roundedBorder)

                            TextField("Муаммо ҳақида изоҳ (ихтиёрий)", text: $comment)
                                .textFieldStyle(.roundedBorder)

                            Button(action: submitApplication) {
                                HStack {
                                    if isSubmitting {
                                        ProgressView()
                                            .progressViewStyle(CircularProgressViewStyle(tint: .white))
                                    } else {
                                        Image(systemName: "arrow.up.circle.fill")
                                        Text("Аризани юбориш")
                                    }
                                }
                                .font(.headline)
                                .foregroundColor(.white)
                                .frame(maxWidth: .infinity)
                                .padding()
                                .background(Color.accentColor)
                                .cornerRadius(12)
                            }
                            .disabled(isSubmitting || fullName.isEmpty || phone.isEmpty)
                        }
                    }
                    .padding()
                    .background(Color(UIColor.secondarySystemBackground))
                    .cornerRadius(20)
                    .padding(.horizontal)
                    .padding(.bottom, 30)
                }
            }
            .navigationTitle("Bekabad Gas")
            .navigationBarTitleDisplayMode(.inline)
            .alert("Хабар", isPresented: $showingAlert) {
                Button("OK", role: .cancel) { }
            } message: {
                Text(alertMessage)
            }
        }
    }

    func triggerHaptic() {
        let generator = UIImpactFeedbackGenerator(style: .medium)
        generator.impactOccurred()
    }

    func callPhone(_ number: String) {
        let cleanNumber = number.replacingOccurrences(of: " ", with: "")
        if let url = URL(string: "tel://\(cleanNumber)") {
            UIApplication.shared.open(url)
        }
    }

    func submitApplication() {
        guard !fullName.isEmpty, !phone.isEmpty else { return }
        isSubmitting = true
        triggerHaptic()

        guard let url = URL(string: "https://bekabadgas.surge.sh/api/submit") else {
            isSubmitting = false
            return
        }

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")

        let body: [String: Any] = [
            "name": fullName,
            "phone": phone,
            "service": service,
            "address": address,
            "comment": comment
        ]

        request.httpBody = try? JSONSerialization.data(withJSONObject: body)

        URLSession.shared.dataTask(with: request) { _, _, _ in
            DispatchQueue.main.async {
                self.isSubmitting = false
                self.alertMessage = "✅ Раҳмат! Мурожаатингиз қабул қилинди. Диспетчер тез орада боғланади!"
                self.showingAlert = true
                self.fullName = ""
                self.phone = ""
                self.address = ""
                self.comment = ""
            }
        }.resume()
    }
}

struct EmergencyMiniButton: View {
    let title: String
    let num: String
    let color: Color

    var body: some View {
        Button(action: {
            if let url = URL(string: "tel://\(num)") {
                UIApplication.shared.open(url)
            }
        }) {
            VStack {
                Text(title)
                    .font(.caption2)
                    .fontWeight(.bold)
                    .foregroundColor(.white)
            }
            .frame(maxWidth: .infinity)
            .padding(.vertical, 10)
            .background(color)
            .cornerRadius(10)
        }
    }
}
