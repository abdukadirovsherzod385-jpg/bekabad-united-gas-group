# «BEKABAD UNITED GAS GROUP» MCHJ - Mobil Ilovalar Tizimi (Android & iPhone)

Ushbu papkada **«BEKABAD UNITED GAS GROUP» MCHJ** korxonasi uchun maxsus ishlab chiqilgan alohida rasmiy mobil dasturlar jamlangan.

---

## 📂 Loyihalar tarkibi:

### 1. 🤖 `android_app/` — Android uchun Native dastur (Kotlin & Jetpack Compose)
- **Texnologiya**: Kotlin, Android Jetpack Compose, Material 3, Android SDK 36.
- **Funksiyalari**:
  - 🚨 **Favqulodda tezkor chaqiruv**: Ilovaga kirgan zahoti eng birinchi bo'lib **104 Gaz Avariya**, **+998 99 823 01 88 (Dispetcher)**, **+998 55 903 22 14 (Bekobod GTB ADX)**, 101, 103, 112 raqamlari chiqadi.
  - ⚡️ **1-bosishda tezkor qo'ng'iroq**: Tugma bosilganda telefon to'g'ridan-to'g'ri terish oynasiga o'tadi va telefonda vibro-signal beradi.
  - 📝 **Onlayn ariza**: Gaz jihozlari ta'miri, sizib chiqish, dudburon tozalash va smeta bo'yicha ariza yuborish.
  - 💬 **Telegram Bot & Sayt**: `@bekabad_united_gas_group_bot` va `https://bekabadgas.surge.sh` ga 1 bosishda o'tish.
- **Qanday ishga tushiriladi / APK olinadi**:
  1. Loyihani **Android Studio** da oching (`File -> Open -> android_app`).
  2. `Build -> Build Bundle(s) / APK(s) -> Build APK(s)` ni bosing.
  3. Tayyor `.apk` fayli telefoningizga o'rnatiladi.

---

### 2. 🍏 `ios_app/` — iPhone (iOS) uchun Native dastur (SwiftUI)
- **Texnologiya**: Apple Swift 5.9, SwiftUI, iOS 16+.
- **Funksiyalari**:
  - 🚨 **Favqulodda tezkor chaqiruv**: 104 Gaz avariya, Dispetcher va GTB ADX raqamlariga 1 bosishda to'g'ridan-to'g'ri qo'ng'iroq qilish (`tel://104`).
  - 📳 **Haptic Feedback**: Har bir muhim favqulodda harakatda iPhone'ning Taptic Engine tebranishi ishlaydi.
  - 📝 **Onlayn ariza shakli**: Ariza yuborilganda markaziy dispetcherga va Telegram botga bir zumda yetib boradi.
  - 💬 **Telegram Deep Linking**: `tg://resolve?domain=bekabad_united_gas_group_bot` orqali Telegram ochiladi.
- **Qanday ishga tushiriladi**:
  1. Loyihani **Xcode** da oching (`ios_app/BekabadGasApp`).
  2. iPhone qurilmangizni ulang yoki Simulatorda **Run (⌘R)** tugmasini bosing.

---

## 🔄 3. Kollaboratsiya va Ekologiya (Barcha Tizimlar Integratsiyasi)

1. **Android Ilova** ⟷ **iPhone Ilova** ⟷ **Veb-sayt** ⟷ **Telegram Bot**:
   - Har qanday ilovadan (Android yoki iPhone) mijoz ariza qoldirsa, bu ma'lumot to'g'ridan-to'g'ri korxona ma'lumotlar bazasiga va Telegram dispetcheriga (@bekabad_united_gas_group_bot) borib tushadi.
   - Saytda ham, ilovada ham, botda ham favqulodda raqamlar bir xil va tezkor teriladi.
